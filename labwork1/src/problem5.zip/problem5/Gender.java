package problem5;

public enum Gender {
	BOY,GIRL
}
